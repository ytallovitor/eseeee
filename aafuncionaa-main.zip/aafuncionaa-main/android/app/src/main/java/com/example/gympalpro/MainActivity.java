package com.example.gympalpro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
