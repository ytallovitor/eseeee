import { Toaster as Sonner } from 'sonner'; // Import Sonner directly

export function Toaster() {
  return <Sonner />;
}